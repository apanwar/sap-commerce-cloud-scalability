package com.sap.cx.boosters.commerce.media.migration.constants;

@SuppressWarnings({"deprecation","squid:CallToDeprecatedMethod"})
public class MediamigrationConstants extends GeneratedMediamigrationConstants
{
	public static final String EXTENSIONNAME = "mediamigration";
	
	private MediamigrationConstants()
	{
		//empty
	}
	
	
}
